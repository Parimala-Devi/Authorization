var config = {
    apiKey: "AIzaSyC796BbPQUL77803LOM1pxUrRp2Fv7ynZU",
    authDomain: "assignment-ff1d2.firebaseapp.com",
    databaseURL: "https://assignment-ff1d2.firebaseio.com",
    projectId: "assignment-ff1d2",
    storageBucket: "assignment-ff1d2.appspot.com",
    messagingSenderId: "362250354548"
};
firebase.initializeApp(config);

var postRef = firebase.database().ref('posts');

$(() => {
    $("#header").load("header.html");


    var doc = "";
    var i = 0;

    postRef.on("value", function(snap) {
        snap.forEach((data) => {

            var data1 = data.val();

            if (data1.catagory == "entertainment") {

                var div = document.createElement('div');
                div.setAttribute('id', i);
                div.setAttribute('class', 'entertainment');

                $("#temp").append(div);

                // var data1 = data.val();

                document.getElementById(i).innerHTML = data1.title + "<br>" + data1.author + "<br>" + data1.date + "<br>" + data1.short + "<br>" + data1.mypost + "<br>";

                doc = doc + (data1.title + "<br>" + data1.author + "<br>" + data1.date + "<br>" + data1.short + "<br>" + data1.mypost);
                i++;
            }

        });
    });
});


var openForm = () => {
    document.getElementById("myForm").style.display = "block";
}


var postFunc = () => {
    var title = getInputVal('title');
    var short = getInputVal('short');
    var mypost = getInputVal('my-post');
    var catagory = "entertainment";
    var d = new Date();
    var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

    //console.log(fullDate);

    var user = firebase.auth().currentUser;
    var email = user.email;
    var res = email.split("@");

    savePost(title, short, mypost, catagory, months[d.getMonth()] + d.getDate() + "," + d.getFullYear(), res[0]);


    document.querySelector('.alert').style.display = 'block';

    setTimeout(function() {
        document.querySelector('.alert').style.display = 'none';
    }, 3000);
    // document.getElementById('reset').reset();
    document.getElementById("reset").value = " ";
    document.getElementById("myForm").style.display = "none";

    //  postUpdate();

}

var getInputVal = (id) => {
    return document.getElementById(id).value;
}

var savePost = (title, short, mypost, catagory, fullDate, name) => {
    var newPostRef = postRef.push();
    var postsRef = postRef.child('posts').push().key;
    console.log(postsRef);
    var data = {
        title: title,
        short: short,
        mypost: mypost,
        catagory: catagory,
        date: fullDate,
        author: name,
        pid: postsRef
    }

    var updates = {};
    updates['/posts/' + postsRef] = data;
    firebase.database().ref().update(updates);
}

function postUpdate() {

    var doc = "";
    var i = 0;

    postRef.on("value", function(snap) {
        snap.forEach((data) => {

            var data1 = data.val();

            if (data1.catagory == "entertainment") {

                var div = document.createElement('div');
                div.setAttribute('id', i);
                div.setAttribute('class', 'entertainment');

                $("#temp").append(div);

                // var data1 = data.val();

                document.getElementById(i).innerHTML = data1.title + "<br>" + data1.author + "<br>" + data1.date + "<br>" + data1.short + "<br>" + data1.mypost + "<br>";

                doc = doc + (data1.title + "<br>" + data1.author + "<br>" + data1.date + "<br>" + data1.short + "<br>" + data1.mypost);
                i++;
            }

        });
        console.log("i" + i);
        var h2 = document.createElement('h2');
        h2.setAttribute('class', 'title');
        $(".entertainment").append(h2);

        console.log($('#' + i - 1));

        var h = $('#' + i - 1).html().split("<br>")[0];
        $(".title").text(h);

        console.log("h:" + h);
    });
}

firebase.auth().onAuthStateChanged(firebaseUser => {
    if (firebaseUser) {
        $(".log-in").css("display", "none");
        if ($(window).width() < 600) {
            $("button").css("width", "100%");
        } else {
            $("button").css("width", "19.7%");
        }
        $(".create").css("display", "block");

        var user = firebase.auth().currentUser;
        var email = user.email;
        var res = email.split("@");
        console.log("res:" + res);

        sessionStorage.setItem('user', email);

        $("#user-name").css("display", "block");
        $("#user-name").text(res[0]);
    } else {

        sessionStorage.removeItem('user');

        $(".log-in").css("display", "inline-block");

        if ($(window).width() < 600) {
            $("button").css("width", "100%");
        } else {
            $("button").css("width", "16.3%");
        }

        $(".create").css("display", "none");
        $("#user-name").css("display", "none");
    }
});

var putOut = () => {
    window.location.href = "index.html";
    firebase.auth().signOut();
}