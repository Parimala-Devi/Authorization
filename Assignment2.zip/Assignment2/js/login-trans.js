"use strict";

var config = {
    apiKey: "AIzaSyC796BbPQUL77803LOM1pxUrRp2Fv7ynZU",
    authDomain: "assignment-ff1d2.firebaseapp.com",
    databaseURL: "https://assignment-ff1d2.firebaseio.com",
    projectId: "assignment-ff1d2",
    storageBucket: "assignment-ff1d2.appspot.com",
    messagingSenderId: "362250354548"
};
firebase.initializeApp(config);

(function () {
    $("#header").load("header.html");

    var uiConfig = {
        callbacks: {
            signInSuccessWithAuthResult: function signInSuccessWithAuthResult(authResult, redirectUrl) {
                // User successfully signed in.
                // Return type determines whether we continue the redirect automatically
                // or whether we leave that to developer to handle.
                return true;
            },
            uiShown: function uiShown() {
                // The widget is rendered.
                // Hide the loader.
                document.getElementById('loader').style.display = 'none';
            }
        },
        signInFlow: 'popup',
        signInSuccessUrl: '/html/index.html',
        signInOptions: [firebase.auth.EmailAuthProvider.PROVIDER_ID],
        // Terms of service url.
        tosUrl: '/html/index.html',
        // Privacy policy url.
        privacyPolicyUrl: '/html/index.html'
    };

    var ui = new firebaseui.auth.AuthUI(firebase.auth());
    // The start method will wait until the DOM is loaded.
    ui.start('#firebaseui-auth-container', uiConfig);
})();

firebase.auth().onAuthStateChanged(function (firebaseUser) {
    if (firebaseUser) {
        $(".log-in").css("display", "none");
        if ($(window).width() < 600) {
            $("button").css("width", "100%");
        } else {
            $("button").css("width", "19.7%");
        }

        var user = firebase.auth().currentUser;
        var email = user.email;
        var res = email.split("@");
        console.log("res:" + res);

        sessionStorage.setItem('user', email);

        $("#user-name").css("display", "block");
        $("#user-name").text(res[0]);
    } else {

        sessionStorage.removeItem('user');

        $(".log-in").css("display", "inline-block");

        if ($(window).width() < 600) {
            $("button").css("width", "15%");
        } else {
            $("button").css("width", "16.3%");
        }

        $("#user-name").css("display", "none");
    }
});

function putOut() {
    window.location.href = "index.html";
    firebase.auth().signOut();
}
