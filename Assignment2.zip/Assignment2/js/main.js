var config = {
    apiKey: "AIzaSyC796BbPQUL77803LOM1pxUrRp2Fv7ynZU",
    authDomain: "assignment-ff1d2.firebaseapp.com",
    databaseURL: "https://assignment-ff1d2.firebaseio.com",
    projectId: "assignment-ff1d2",
    storageBucket: "assignment-ff1d2.appspot.com",
    messagingSenderId: "362250354548"
};

firebase.initializeApp(config);

var catRef = firebase.database().ref('catagory');
var postRef = firebase.database().ref('posts');

postRef.on("value", function(doc) {
    doc.forEach((data) => {
        var get = data.val();
        console.log("get " + data.child("posts/title").val());
        console.log("post id in func postupdate: " + get.postid);
        var card = document.createElement('post-card');
        card.setAttribute('postId', get.postid);
        $("#content").append(card);
        console.log("card :  " + card);
    });
});
$("#home").click(() => {

});

$("#tech").click(() => {
    postRef.on("value", function(doc) {
        doc.forEach((data) => {
            var get = data.val();
            console.log("get " + data.child("posts/title").val());
            console.log("post id in func postupdate: " + get.postid);
            var card = document.createElement('post-card');
            card.setAttribute('postId', '1');
            $("#content").append(card);
            console.log("card :  " + card);
        });
    });
});

$("#science").click(() => {
    postRef.on("value", function(doc) {
        doc.forEach((data) => {
            var get = data.val();
            console.log("get " + data.child("posts/title").val());
            console.log("post id in func postupdate: " + get.postid);
            var card = document.createElement('post-card');
            card.setAttribute('postId', '2');
            $("#content").append(card);
            console.log("card :  " + card);
        });
    });
});

$("#entertainment").click(() => {
    postRef.on("value", function(doc) {
        doc.forEach((data) => {
            var get = data.val();
            console.log("get " + data.child("posts/title").val());
            console.log("post id in func postupdate: " + get.postid);
            var card = document.createElement('post-card');
            card.setAttribute('postId', '3');
            $("#content").append(card);
            console.log("card :  " + card);
        });
    });
});

function saveCat(catagory, postid) {
    var catsRef = catRef.child('catagory').push().key;
    console.log(catsRef);
    var data = {
        catagory: catagory,
        postid: postid,
        pid: catsRef
    }

    var updates = {};
    updates['/catagory/' + catsRef] = data;
    firebase.database().ref().update(updates);
}

$(() => {
    $("#header").load("header.html");

    var doc = "";
    var i = 0;

    postRef.on("value", function(snap) {
        snap.forEach((data) => {

            var data1 = data.val();

            var div = document.createElement('div');
            div.setAttribute('id', i);

            $("#temp").append(div);

            document.getElementById(i).innerHTML = data1.title + "<br>" + data1.author + "<br>" + data1.date + "<br>" + data1.short + "<br>" + data1.mypost + "<br>";

            doc = doc + (data1.title + "<br>" + data1.author + "<br>" + data1.date + "<br>" + data1.short + "<br>" + data1.mypost);
            i++;

        });
    });
    /*   postRef.on("value", function(doc) {
           doc.forEach((data) => {
               var get = data.val();
               console.log("post id in func postupdate: " + get.postid);
               var div = document.createElement('post-card');
               div.setAttribute('postId', get.postid);
               $("#content").append(div);
               console.log("div " + div);
           });
       });*/
});

function putOut() {
    window.location.href = "index.html";
    firebase.auth().signOut();
}


function openForm() {
    document.getElementById("myForm").style.display = "block";
}


function postFunc() {
    var title = getInputVal('title');
    var short = getInputVal('short');
    var mypost = getInputVal('my-post');
    var catagory = getInputVal('catagory');
    var d = new Date();
    var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

    var user = firebase.auth().currentUser;
    var email = user.email;
    var res = email.split("@");
    var postid1 = 0;
    if (catagory == "technology") {
        postid1 = 1;
    } else if (catagory == "science") {
        postid1 = 2;
    } else if (catagory == "entertainment") {
        postid1 = 3;
    }

    console.log("Before func: " + postid1);

    // getpostid();

    console.log("After func: " + postid1);

    savePost(title, short, mypost, catagory, postid1, months[d.getMonth()] + d.getDate() + "," + d.getFullYear(), res[0]);


    document.querySelector('.alert').style.display = 'block';

    setTimeout(function() {
        document.querySelector('.alert').style.display = 'none';
    }, 3000);

    document.getElementById("reset").value = " ";
    document.getElementById("myForm").style.display = "none";

    postUpdate(postid1);

}

function getInputVal(id) {
    return document.getElementById(id).value;
}

function getpostid() {
    catRef.on("value", function(snapshot) {
        snapshot.forEach((datas) => {

            var catdata = datas.val();

            if (catdata.catagory == catagory) {
                console.log(catdata.postid);
                postid1 = catdata.postid;
                console.log("In func : " + postid1);
            }
        });
    });
    console.log("catagory: " + catagory);
}

function savePost(title, short, mypost, catagory, postid1, fullDate, name) {
    var newPostRef = postRef.push();
    var postsRef = postRef.child('posts').push().key;
    console.log(postsRef);
    var data = {
        title: title,
        short: short,
        mypost: mypost,
        catagory: catagory,
        postid: postid1,
        date: fullDate,
        author: name,
        pid: postsRef
    }

    var updates = {};
    updates['/posts/' + postsRef] = data;
    firebase.database().ref().update(updates);
    /*  newPostRef.set({
          title: title,
          short: short,
          mypost: mypost,
          catagory: catagory,
          date: fullDate,
          author: name,
          pid: r
      });*/

}

function postUpdate(postid) {
    /* var div = document.createElement('post-card');
     div.postCatagory = "technology"
     $("#temp").append(div);*/

    var newPostRef = postRef.push();
    var postsRef = postRef.child('posts').push().key;

    /*  postRef.on("value", function(doc) {
          doc.forEach((data) => {
              var get = data.val();
              console.log("entering");
              console.log("get " + get);
              
              var recentPostsRef = firebase.database().ref('posts').equalTo(postid);
              */
    postRef.orderByChild("date").equalTo(postid).on("value", function(snap) {
        console.log("post id in func postupdate: " + postid);
        var div = document.createElement('post-card');
        div.setAttribute('postId', postid);
        $("#content").append(div);
        console.log("div " + div);
    });
    /*  });
    });*/
}

firebase.auth().onAuthStateChanged(firebaseUser => {
    if (firebaseUser) {
        console.log("logged in");
        $("#login").css("display", "none"); //login button hide
        $("#logout").css("display", "inline-block"); //logout button show
        $(".create").css("display", "block"); //create-post button show

        var user = firebase.auth().currentUser;
        var email = user.email;
        var res = email.split("@");
        console.log("res:" + res);

        $("#user").css("display", "inline-block");
        $("#user").text(res[0]);
        sessionStorage.setItem('user', email);

    } else {
        $(".create").css("display", "none"); //create-post button hide
        $("#login").css("display", "inline-block"); //login button show
        $("#logout").css("display", "none"); //logout button hide
        sessionStorage.removeItem('user');

    }
});