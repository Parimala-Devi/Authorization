(function() {
    const currentDocument = document.currentScript.ownerDocument;

    /* define(['require', 'cors'], function(require) {
         var namedModule = require('cors');
     });
    require.config({
        origin: true
    });*/

    require(['dependency'], function(dependency) {});

    class PostCard extends HTMLElement {
        constructor() {
            console.log("entering post");
            super();

            // Setup a click listener on <user-card>
            /*  this.addEventListener('click', e => {
                  this.toggleCard();
              });*/
        }

        /*toggleCard() {
            console.log("Element was clicked!");
        }*/
        connectedCallback() {

                // const cors = require('cors')({ origin: true });
                const cors = require(['cors', { origin: ["*"] }]);
                const shadowRoot = this.attachShadow({ mode: 'open' });

                // Select the template and clone it. Finally attach the cloned node to the shadowDOM's root.
                // Current document needs to be defined to get DOM access to imported HTML
                const template = currentDocument.querySelector('#post-card-template');
                const instance = template.content.cloneNode(true);
                shadowRoot.appendChild(instance);

                // Extract the attribute user-id from our element. 
                // Note that we are going to specify our cards like: 
                // <user-card user-id="1"></user-card>
                const postCat = this.getAttribute('postCatagory');

                // Fetch the data for that user Id from the API and call the render method with this data
                fetch(`https://assignment-ff1d2.firebaseio.com/posts/${postCat}`)
                    .then((response) => response.text())
                    .then((responseText) => {
                        this.render(JSON.parse(responseText));
                    })
                    .catch((error) => {
                        console.error(error);
                    });
            }
            //  this.list.forEach(person => {
        render(postData) {

            //  this.list.forEach(candidateData => {
            this.shadowRoot.querySelector('.card__title').innerHTML = postData.title;
            this.shadowRoot.querySelector('.card__author').innerHTML = postData.author;
            this.shadowRoot.querySelector('.card__short').innerHTML = postData.short;
            this.shadowRoot.querySelector('.card__catagory').innerHTML = postData.catagory;
            this.shadowRoot.querySelector('.card__desc').innerHTML = postData.mypost;
        }

        /*  toggleCard() {
              let elem = this.shadowRoot.querySelector('.card__hidden-content');
              let btn = this.shadowRoot.querySelector('.card__details-btn');
              btn.innerHTML = elem.style.display == 'none' ? 'Less Details' : 'More Details';
              elem.style.display = elem.style.display == 'none' ? 'block' : 'none';
          }*/
    }

    customElements.define('post-card', PostCard);


}());