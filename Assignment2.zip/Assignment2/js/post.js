(function() {
    const currentDocument = document.currentScript.ownerDocument;

    var postRef = firebase.database().ref('posts');

    var catRef = firebase.database().ref('catagory');

    /* define(['require', 'cors'], function(require) {
         var namedModule = require('cors');
     });
    require.config({
        origin: true
    });*/

    // require(['cors'], function(origin) { origin: true });

    class PostCard extends HTMLElement {

        constructor() {
            console.log("entering post");
            super();

            // Setup a click listener on <user-card>
            /*  this.addEventListener('click', e => {
                  this.toggleCard();
              });*/
        }

        /*toggleCard() {
            console.log("Element was clicked!");
        }*/
        connectedCallback() {

                // const cors = require('cors')({ origin: true });
                //  const cors = require(['cors', { origin: ["*"] }]);
                const shadowRoot = this.attachShadow({ mode: 'open' });

                // Select the template and clone it. Finally attach the cloned node to the shadowDOM's root.
                // Current document needs to be defined to get DOM access to imported HTML
                const template = currentDocument.querySelector('#post-card-template');
                const instance = template.content.cloneNode(true);
                shadowRoot.appendChild(instance);

                // Extract the attribute user-id from our element. 
                // Note that we are going to specify our cards like: 
                // <user-card user-id="1"></user-card>
                console.log("entering post js");
                const postId = this.getAttribute('postId');
                console.log("js postId" + postId);
                //  var recentPostsRef = firebase.database().ref('posts').equalTo(postId);
                var recentPostsRef = firebase.database().ref('posts/' + postId);
                console.log(recentPostsRef);
                // const postElement = () => {

                recentPostsRef.once('value', function(snapshot) {
                    snapshot.forEach(function(childSnapshot) {
                        //  var childKey = childSnapshot.key;
                        console.log("entering post element func");
                        var childData = childSnapshot.val();
                        this.render(childData);
                    });
                });
                //   }
                // Fetch the data for that user Id from the API and call the render method with this data
                /* fetch(`https://assignment-ff1d2.firebaseio.com/posts/${postId}`)
                     .then((response) => response.text())
                     .then((responseText) => {
                         this.render(JSON.parse(responseText));
                         console.log('Step 3 : ' + responseText);
                     })
                     .catch((error) => {
                         console.error(error);
                         console.log('Step 4 : Error');
                     });*/

            }
            //  this.list.forEach(person => {
        render(postData) {

            //  this.list.forEach(candidateData => {
            this.shadowRoot.querySelector('.card__title').innerHTML = postData.title;
            this.shadowRoot.querySelector('.card__author').innerHTML = postData.author;
            this.shadowRoot.querySelector('.card__short').innerHTML = postData.short;
            this.shadowRoot.querySelector('.card__catagory').innerHTML = postData.catagory;
            this.shadowRoot.querySelector('.card__desc').innerHTML = postData.mypost;
        }


        /*  toggleCard() {
              let elem = this.shadowRoot.querySelector('.card__hidden-content');
              let btn = this.shadowRoot.querySelector('.card__details-btn');
              btn.innerHTML = elem.style.display == 'none' ? 'Less Details' : 'More Details';
              elem.style.display = elem.style.display == 'none' ? 'block' : 'none';
          }*/
    }

    customElements.define('post-card', PostCard);


}());