'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

(function () {
    var currentDocument = document.currentScript.ownerDocument;

    var postRef = firebase.database().ref('posts');

    var catRef = firebase.database().ref('catagory');

    /* define(['require', 'cors'], function(require) {
         var namedModule = require('cors');
     });
    require.config({
        origin: true
    });*/

    // require(['cors'], function(origin) { origin: true });

    var PostCard = function (_HTMLElement) {
        _inherits(PostCard, _HTMLElement);

        function PostCard() {
            _classCallCheck(this, PostCard);

            console.log("entering post");
            return _possibleConstructorReturn(this, (PostCard.__proto__ || Object.getPrototypeOf(PostCard)).call(this));

            // Setup a click listener on <user-card>
            /*  this.addEventListener('click', e => {
                  this.toggleCard();
              });*/
        }

        /*toggleCard() {
            console.log("Element was clicked!");
        }*/


        _createClass(PostCard, [{
            key: 'connectedCallback',
            value: function connectedCallback() {

                // const cors = require('cors')({ origin: true });
                //  const cors = require(['cors', { origin: ["*"] }]);
                var shadowRoot = this.attachShadow({ mode: 'open' });

                // Select the template and clone it. Finally attach the cloned node to the shadowDOM's root.
                // Current document needs to be defined to get DOM access to imported HTML
                var template = currentDocument.querySelector('#post-card-template');
                var instance = template.content.cloneNode(true);
                shadowRoot.appendChild(instance);

                // Extract the attribute user-id from our element. 
                // Note that we are going to specify our cards like: 
                // <user-card user-id="1"></user-card>
                console.log("entering post js");
                var postId = this.getAttribute('postId');
                console.log("js postId" + postId);
                //  var recentPostsRef = firebase.database().ref('posts').equalTo(postId);
                var recentPostsRef = firebase.database().ref('posts/' + postId);
                console.log(recentPostsRef);
                // const postElement = () => {

                recentPostsRef.once('value', function (snapshot) {
                    snapshot.forEach(function (childSnapshot) {
                        //  var childKey = childSnapshot.key;
                        console.log("entering post element func");
                        var childData = childSnapshot.val();
                        this.render(childData);
                    });
                });
                //   }
                // Fetch the data for that user Id from the API and call the render method with this data
                /* fetch(`https://assignment-ff1d2.firebaseio.com/posts/${postId}`)
                     .then((response) => response.text())
                     .then((responseText) => {
                         this.render(JSON.parse(responseText));
                         console.log('Step 3 : ' + responseText);
                     })
                     .catch((error) => {
                         console.error(error);
                         console.log('Step 4 : Error');
                     });*/
            }
            //  this.list.forEach(person => {

        }, {
            key: 'render',
            value: function render(postData) {

                //  this.list.forEach(candidateData => {
                this.shadowRoot.querySelector('.card__title').innerHTML = postData.title;
                this.shadowRoot.querySelector('.card__author').innerHTML = postData.author;
                this.shadowRoot.querySelector('.card__short').innerHTML = postData.short;
                this.shadowRoot.querySelector('.card__catagory').innerHTML = postData.catagory;
                this.shadowRoot.querySelector('.card__desc').innerHTML = postData.mypost;
            }

            /*  toggleCard() {
                  let elem = this.shadowRoot.querySelector('.card__hidden-content');
                  let btn = this.shadowRoot.querySelector('.card__details-btn');
                  btn.innerHTML = elem.style.display == 'none' ? 'Less Details' : 'More Details';
                  elem.style.display = elem.style.display == 'none' ? 'block' : 'none';
              }*/

        }]);

        return PostCard;
    }(HTMLElement);

    customElements.define('post-card', PostCard);
})();
