var config = {
    apiKey: "AIzaSyC796BbPQUL77803LOM1pxUrRp2Fv7ynZU",
    authDomain: "assignment-ff1d2.firebaseapp.com",
    databaseURL: "https://assignment-ff1d2.firebaseio.com",
    projectId: "assignment-ff1d2",
    storageBucket: "assignment-ff1d2.appspot.com",
    messagingSenderId: "362250354548"
};
firebase.initializeApp(config);

var postRef = firebase.database().ref('posts');

$(document).ready(() => {
    $("#header").load("header.html");

    var doc = "";
    var i = 0;

    postRef.on("value", function(snap) {
        snap.forEach((data) => {

            var data1 = data.val();

            var div = document.createElement('div');
            div.setAttribute('id', i);
            div.setAttribute('class', 'science');

            $("#temp").append(div);

            document.getElementById(i).innerHTML = data1.title + "<br>" + data1.author + "<br>" + data1.date + "<br>" + data1.short + "<br>" + data1.mypost + "<br>";

            doc = doc + (data1.title + "<br>" + data1.author + "<br>" + data1.date + "<br>" + data1.short + "<br>" + data1.mypost);
            i++;

        });
    });
});


function postUpdate() {
    var div = document.createElement('post-card');
    $(".task-to-do").append(div);
}

firebase.auth().onAuthStateChanged(firebaseUser => {
    if (firebaseUser) {
        $(".log-in").css("display", "none");
        if ($(window).width() < 600) {
            $("button").css("width", "100%");
        } else {
            $("button").css("width", "19.7%");
        }
        $(".create").css("display", "block");

        var user = firebase.auth().currentUser;
        var email = user.email;
        var res = email.split("@");
        console.log("res:" + res);

        sessionStorage.setItem('user', email);

        $("#user-name").css("display", "block");
        $("#user-name").text(res[0]);
    } else {

        sessionStorage.removeItem('user');

        $(".log-in").css("display", "inline-block");

        if ($(window).width() < 600) {
            $("button").css("width", "100%");
        } else {
            $("button").css("width", "16.3%");
        }

        $("#user-name").css("display", "none");
    }
});

function putOut() {
    window.location.href = "index.html";
    firebase.auth().signOut();
}