"use strict";

var config = {
    apiKey: "AIzaSyC796BbPQUL77803LOM1pxUrRp2Fv7ynZU",
    authDomain: "assignment-ff1d2.firebaseapp.com",
    databaseURL: "https://assignment-ff1d2.firebaseio.com",
    projectId: "assignment-ff1d2",
    storageBucket: "assignment-ff1d2.appspot.com",
    messagingSenderId: "362250354548"
};
firebase.initializeApp(config);

var postRef = firebase.database().ref('posts');

postRef.on('value', function (doc) {
    // const cors = require('cors')({ origin: true });
    doc.forEach(function (data) {
        var get = data.val();
        console.log("entering");
        console.log("get " + data.child("posts/title").val());
        if (get.catagory == "technology") {
            var div = document.createElement('post-card');
            div.setAttribute('postCatagory', 'technology');
            $("#temp").append(div);
            console.log("div " + div);
        }
    });
});

$(document).ready(function () {
    $("#header").load("header.html");
});

function openForm() {
    document.getElementById("myForm").style.display = "block";
}

function postFunc() {
    var title = getInputVal('title');
    var short = getInputVal('short');
    var mypost = getInputVal('my-post');
    var catagory = "technology";
    var d = new Date();
    var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

    //console.log(fullDate);

    var user = firebase.auth().currentUser;
    var email = user.email;
    var res = email.split("@");

    savePost(title, short, mypost, catagory, months[d.getMonth()] + d.getDate() + "," + d.getFullYear(), res[0]);

    document.querySelector('.alert').style.display = 'block';

    setTimeout(function () {
        document.querySelector('.alert').style.display = 'none';
    }, 3000);
    // document.getElementById('reset').reset();
    document.getElementById("reset").value = " ";
    document.getElementById("myForm").style.display = "none";

    postUpdate(postid);
}

function getInputVal(id) {
    return document.getElementById(id).value;
}

function savePost(title, short, mypost, catagory, fullDate, name) {
    var newPostRef = postRef.push();
    var postsRef = postRef.child('posts').push().key;
    console.log(postsRef);
    var data = {
        title: title,
        short: short,
        mypost: mypost,
        catagory: catagory,
        date: fullDate,
        author: name,
        pid: postsRef
    };

    var updates = {};
    updates['/posts/' + postsRef] = data;
    firebase.database().ref().update(updates);
    /*  newPostRef.set({
          title: title,
          short: short,
          mypost: mypost,
          catagory: catagory,
          date: fullDate,
          author: name,
          pid: r
      });*/
}

function postUpdate(postid) {
    /* var div = document.createElement('post-card');
     div.postCatagory = "technology"
     $("#temp").append(div);*/

    var newPostRef = postRef.push();
    var postsRef = postRef.child('posts').push().key;

    postRef.on("value", function (doc) {
        doc.forEach(function (data) {
            var get = data.val();
            console.log("entering");
            console.log("get " + get);

            var div = document.createElement('post-card');
            div.setAttribute('postId', postid);
            $("#temp").append(div);
            console.log("div " + div);
        });
    });
}

firebase.auth().onAuthStateChanged(function (firebaseUser) {
    if (firebaseUser) {
        console.log($.support.cors);
        $(".log-in").css("display", "none");
        if ($(window).width() < 600) {
            $("button").css("width", "100%");
        } else {
            $("button").css("width", "19.7%");
        }
        $(".create").css("display", "block");

        var user = firebase.auth().currentUser;
        var email = user.email;
        var res = email.split("@");
        console.log("res:" + res);

        sessionStorage.setItem('user', email);

        $("#user-name").css("display", "block");
        $("#user-name").text(res[0]);
    } else {

        sessionStorage.removeItem('user');

        $(".log-in").css("display", "inline-block");

        if ($(window).width() < 600) {
            $("button").css("width", "100%");
        } else {
            $("button").css("width", "16.3%");
        }

        $(".create").css("display", "none");
        $("#user-name").css("display", "none");
    }
});

function putOut() {
    window.location.href = "index.html";
    firebase.auth().signOut();
}
